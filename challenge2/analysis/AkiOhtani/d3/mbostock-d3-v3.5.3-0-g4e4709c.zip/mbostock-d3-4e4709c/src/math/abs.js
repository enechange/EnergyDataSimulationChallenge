var abs = Math.abs;
